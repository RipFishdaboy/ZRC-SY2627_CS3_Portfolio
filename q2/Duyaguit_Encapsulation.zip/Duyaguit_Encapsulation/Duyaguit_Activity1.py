# Activity 1: Public, Protected, and Private Attributes

# 1. Public attribute
class GameCharacter:
    def __init__(self, username):
        self.username = username

# 2. Private attribute
class BankAccount:
    def __init__(self, balance):
        self.__balance = balance

# 3. Protected attribute
class Vehicle:
    def __init__(self, engineCode):
        self._engineCode = engineCode

# 4. Public attribute
class Student:
    def __init__(self, schoolName):
        self.schoolName = schoolName

# 5. Private attribute
class VotingSystem:
    def __init__(self, voterID):
        self.__voterID = voterID