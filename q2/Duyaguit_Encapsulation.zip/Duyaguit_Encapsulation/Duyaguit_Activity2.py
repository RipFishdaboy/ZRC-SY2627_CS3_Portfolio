# Activity 2: Rectangle Class

class Rectangle:
    def __init__(self, width, height):
        self.__width = width
        self.__height = height

    # Get methods
    def get_width(self):
        return self.__width

    def get_height(self):
        return self.__height

    # Set methods
    def set_width(self, width):
        if width > 0:
            self.__width = width
        else:
            print("Width must be positive.")

    def set_height(self, height):
        if height > 0:
            self.__height = height
        else:
            print("Height must be positive.")

    # Calculate area
    def get_area(self):
        return self.__width * self.__heigh